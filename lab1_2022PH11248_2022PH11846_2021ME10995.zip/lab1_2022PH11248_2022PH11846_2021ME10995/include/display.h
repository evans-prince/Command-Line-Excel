#ifndef DISPLAY_H
#define DISPLAY_H

#include "spreadsheet.h"

void display_sheet(sheet *s);

#endif
